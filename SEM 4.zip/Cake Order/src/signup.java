import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Arrays;
import java.awt.event.ActionEvent;

public class signup extends JFrame {

	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;
	private JPasswordField password1;
	private JPasswordField password2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup frame = new signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signup() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DELL\\Desktop\\New folder\\123.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 900);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 228, 181));
		panel.setBounds(25, 25, 934, 700);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label1 = new JLabel("Name:");
		label1.setForeground(new Color(128, 0, 0));
		label1.setBackground(new Color(230, 230, 250));
		label1.setFont(new Font("Tahoma", Font.BOLD, 18));
		label1.setBounds(58, 58, 90, 25);
		panel.add(label1);
		
		JLabel label2 = new JLabel("Mobile Number:");
		label2.setForeground(new Color(128, 0, 0));
		label2.setFont(new Font("Tahoma", Font.BOLD, 18));
		label2.setBounds(58, 129, 149, 25);
		panel.add(label2);
		
		JLabel label3 = new JLabel("Create Password:");
		label3.setForeground(new Color(128, 0, 0));
		label3.setFont(new Font("Tahoma", Font.BOLD, 18));
		label3.setBounds(58, 201, 165, 25);
		panel.add(label3);
		
		JLabel label4 = new JLabel("Confirm Password:");
		label4.setForeground(new Color(128, 0, 0));
		label4.setFont(new Font("Tahoma", Font.BOLD, 18));
		label4.setBounds(58, 274, 184, 25);
		panel.add(label4);
		
		txt1 = new JTextField();
		txt1.setBounds(308, 58, 165, 25);
		panel.add(txt1);
		txt1.setColumns(10);
		
		txt2 = new JTextField();
		txt2.setColumns(10);
		txt2.setBounds(308, 129, 165, 25);
		panel.add(txt2);
		
		password1 = new JPasswordField();
		password1.setBounds(309, 201, 164, 25);
		panel.add(password1);
		
		password2 = new JPasswordField();
		password2.setBounds(309, 274, 164, 25);
		panel.add(password2);
		
		JButton btn1 = new JButton("Back");
		btn1.setForeground(new Color(255, 228, 181));
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login j = new login();
				j.setVisible(true);
			}
		});
		btn1.setBackground(new Color(128, 0, 0));
		btn1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btn1.setBounds(100, 336, 107, 50);
		panel.add(btn1);
		
		JButton btn2 = new JButton("Sign Up");
		btn2.setForeground(new Color(255, 228, 181));
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!(Arrays.equals(password1.getPassword(),password2.getPassword())))
				{
					JOptionPane.showMessageDialog(btn2, "Password does not match");
				}
				else
				{
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onesign","root","Lavanya@02");
						String query="insert into registration values(?,?,?)";
						PreparedStatement ps=con.prepareStatement(query);
						ps.setString(1, txt1.getText());
						ps.setString(2, txt2.getText());
						ps.setString(3, password1.getText());
						int i = ps.executeUpdate();
					
					} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					}
					login j = new login();
					j.setVisible(true);
					JOptionPane.showMessageDialog(btn2, "Account Signup Successfully");
				}
				
			}
		});
		btn2.setBackground(new Color(128, 0, 0));
		btn2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btn2.setBounds(302, 336, 117, 50);
		panel.add(btn2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(128, 0, 0));
		panel_1.setBounds(525, 11, 399, 678);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label5 = new JLabel("");
		label5.setIcon(new ImageIcon("C:\\Users\\DELL\\Desktop\\New folder\\1.jpg"));
		label5.setBounds(10, 11, 379, 656);
		panel_1.add(label5);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(128, 0, 0));
		panel_2.setBounds(110, 413, 282, 251);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label6 = new JLabel("");
		label6.setIcon(new ImageIcon("C:\\Users\\DELL\\Downloads\\signup logo.png"));
		label6.setBounds(36, 11, 213, 229);
		panel_2.add(label6);
	}

}
