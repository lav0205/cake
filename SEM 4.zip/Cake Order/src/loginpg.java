import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class loginpg extends JFrame {

	private JPanel contentPane;
	private JTextField txt1;
	private JPasswordField password1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginpg frame = new loginpg();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginpg() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DELL\\Desktop\\New folder\\123.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 228, 181));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(128, 0, 0));
		panel.setBounds(255, 0, 629, 572);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label2 = new JLabel("Mobile Number");
		label2.setBackground(new Color(0, 0, 0));
		label2.setForeground(new Color(255, 228, 181));
		label2.setFont(new Font("Tahoma", Font.BOLD, 18));
		label2.setBounds(138, 267, 140, 34);
		panel.add(label2);
		
		JLabel label3 = new JLabel("Password");
		label3.setForeground(new Color(255, 228, 181));
		label3.setFont(new Font("Tahoma", Font.BOLD, 18));
		label3.setBounds(138, 347, 140, 34);
		panel.add(label3);
		
		txt1 = new JTextField();
		txt1.setBounds(343, 267, 193, 34);
		panel.add(txt1);
		txt1.setColumns(10);
		
		password1 = new JPasswordField();
		password1.setBounds(343, 347, 193, 34);
		panel.add(password1);
		
		JButton btn1 = new JButton("Login");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				if(txt1.getText().isEmpty() || password1.getText().isEmpty()) {
					JOptionPane.showMessageDialog(btn1, "Enter Mobile no and Password");
					
				}
				else {
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onesign","root","Lavanya@02");
						String s="select * from registration where mobileno=? and password=?";
						PreparedStatement ps=con.prepareStatement(s);
						ps.setString(1,txt1.getText());
						ps.setString(2,password1.getText());
						ResultSet ts=ps.executeQuery();
						if(ts.next()==true)
						{
							menu j = new menu();
							j.setVisible(true);
						}
						else
						{
							txt1.setText("");
							password1.setText("");
							JOptionPane.showMessageDialog(btn1,"Incorrect Mobile no or Password");
						}
						
						}
						catch(Exception e1) {
						//TODO Auto-generated catch block
						e1.printStackTrace();
						
						}
					menu j= new menu();
					j.setVisible(true);
					JOptionPane.showMessageDialog(btn1, "Account Login Successfully");
				}
				
				
			}
		});
		btn1.setForeground(new Color(128, 0, 0));
		btn1.setBackground(new Color(255, 228, 181));
		btn1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn1.setBounds(278, 429, 106, 54);
		panel.add(btn1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 250, 205));
		panel_2.setBounds(220, 30, 207, 212);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel label4 = new JLabel("");
		label4.setIcon(new ImageIcon("C:\\Users\\DELL\\Desktop\\New folder\\login logo.jpg"));
		label4.setBounds(10, 11, 187, 191);
		panel_2.add(label4);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(128, 0, 0));
		panel_1.setBounds(36, 120, 183, 322);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label1 = new JLabel("");
		label1.setIcon(new ImageIcon("C:\\Users\\DELL\\Desktop\\New folder\\1cake.jpg"));
		label1.setBounds(10, 11, 163, 300);
		panel_1.add(label1);
	}

}
