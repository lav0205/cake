import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class menu2 extends JFrame {

	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;
	private JTable t1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu2 frame = new menu2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menu2() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DELL\\Desktop\\New folder\\123.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1206, 833);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 250, 205));
		panel.setBounds(34, 34, 1121, 679);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label1 = new JLabel("Pastry Types");
		label1.setForeground(new Color(128, 0, 0));
		label1.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label1.setBounds(86, 71, 161, 36);
		panel.add(label1);
		
		JComboBox cb1 = new JComboBox();
		cb1.setBounds(360, 71, 202, 36);
		panel.add(cb1);
		cb1.setModel(new DefaultComboBoxModel(new String[] {"","Puff","Choux","Shortcrust","Filo","Flasky","Eclair","Crossiant","Macaron","Cannoli","Others"}));
		
		JLabel label2 = new JLabel("Price");
		label2.setForeground(new Color(128, 0, 0));
		label2.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label2.setBounds(86, 154, 74, 36);
		panel.add(label2);
		
		JComboBox cb2 = new JComboBox();
		cb2.setBounds(358, 154, 204, 36);
		panel.add(cb2);
		cb2.setModel(new DefaultComboBoxModel(new String[] {"","100/-","120/-","150/-","180/-","200/-","220/-","250/-","280/-","300/-"}));
		
		JLabel label3 = new JLabel("Required Date");
		label3.setForeground(new Color(128, 0, 0));
		label3.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label3.setBounds(86, 240, 179, 28);
		panel.add(label3);
		
		txt1 = new JTextField();
		txt1.setColumns(10);
		txt1.setBounds(363, 232, 199, 36);
		panel.add(txt1);
		
		JButton btn1 = new JButton("Back");
		btn1.setForeground(new Color(255, 250, 205));
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu j = new menu();
				j.setVisible(true);
			}
		});
		btn1.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn1.setBackground(new Color(128, 0, 0));
		btn1.setBounds(117, 393, 98, 47);
		panel.add(btn1);
		
		JButton btn2 = new JButton("Submit");
		btn2.setForeground(new Color(255, 250, 205));
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(txt1.getText().isEmpty() || txt2.getText().isEmpty()) {
					JOptionPane.showMessageDialog(btn2, "Enter Your Details");
					
				}
				else {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onesign","root","Lavanya@02");
					String query="insert into pastrieslist values(?,?,?,?)";
					PreparedStatement ps=con.prepareStatement(query);
					ps.setString(1, cb1.getSelectedItem().toString());
					ps.setString(2, cb2.getSelectedItem().toString());
					ps.setString(3, txt1.getText());
					ps.setString(4, txt2.getText());
					int i = ps.executeUpdate();
				
				} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(btn2, "Order Submitted Successfully...");
			
			}
			}
		});
		btn2.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn2.setBackground(new Color(128, 0, 0));
		btn2.setBounds(421, 393, 121, 47);
		panel.add(btn2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(128, 0, 0));
		panel_1.setBounds(853, 376, 188, 263);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label4 = new JLabel("");
		label4.setIcon(new ImageIcon("C:\\Users\\DELL\\Desktop\\New folder\\pastry.jpg"));
		label4.setBounds(10, 11, 167, 239);
		panel_1.add(label4);
		
		JLabel label5 = new JLabel("Mobile Number");
		label5.setForeground(new Color(128, 0, 0));
		label5.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label5.setBounds(86, 324, 188, 28);
		panel.add(label5);
		
		txt2 = new JTextField();
		txt2.setColumns(10);
		txt2.setBounds(360, 316, 199, 36);
		panel.add(txt2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(128, 0, 0));
		panel_2.setBounds(638, 36, 444, 294);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		t1 = new JTable();
		t1.setFont(new Font("Century Schoolbook", Font.BOLD, 12));
		t1.setBackground(new Color(255, 250, 205));
		t1.setForeground(new Color(0, 0, 0));
		t1.setModel(new DefaultTableModel(
			new Object[][] {
				{"Pastry Types", "Price", "Required Date", "Mobile Number"},
			},
			new String[] {
					"Pastry Types", "Price", "Required Date", "Mobile Number"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		t1.getColumnModel().getColumn(0).setResizable(false);
		t1.setSurrendersFocusOnKeystroke(true);
		t1.setFillsViewportHeight(true);
		t1.setColumnSelectionAllowed(true);
		t1.setCellSelectionEnabled(true);
		t1.setBounds(10, 11, 423, 271);
		panel_2.add(t1);
		
		JButton btn3 = new JButton("Bill");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onesign","root","Lavanya@02");
					Statement st=con.createStatement();
					String query="select * from pastrieslist";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd= (ResultSetMetaData) rs.getMetaData();
					DefaultTableModel model=(DefaultTableModel) t1.getModel();
					
					int cols=rsmd.getColumnCount();
					String[] colName=new String[cols];
					for(int i=0;i<cols;i++)
						colName[i]=rsmd.getColumnName(i+1);
					model.setColumnIdentifiers(colName);
					String pastrytypes,price,requireddate,mobilenumber;
					while(rs.next()) {
						pastrytypes=rs.getString(1);
						price=rs.getString(2);
						requireddate=rs.getString(3);
						mobilenumber=rs.getString(4);
						String[] row= {pastrytypes,price,requireddate,mobilenumber};
						model.addRow(row);
					}
					st.close();
					con.close();     
				}
					
					
					catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
				} 
				}
				
				
				});

				
		btn3.setForeground(new Color(255, 250, 205));
		btn3.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn3.setBackground(new Color(128, 0, 0));
		btn3.setBounds(271, 570, 91, 47);
		panel.add(btn3);
		
		JButton btn4 = new JButton("Finish");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(btn3, "Thank You For Your Order...");
			}
		});
		btn4.setForeground(new Color(255, 250, 205));
		btn4.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn4.setBackground(new Color(128, 0, 0));
		btn4.setBounds(580, 570, 123, 47);
		panel.add(btn4);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBackground(new Color(128, 0, 0));
		panel_3.setBounds(0, 484, 1121, 37);
		panel.add(panel_3);
		
		JButton btn5 = new JButton("Add");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu j = new menu();
				j.setVisible(true);
			}
		});
		btn5.setForeground(new Color(255, 250, 205));
		btn5.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn5.setBackground(new Color(128, 0, 0));
		btn5.setBounds(732, 393, 85, 47);
		panel.add(btn5);
		
		
	}
}
