import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu frame = new menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menu() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DELL\\Desktop\\New folder\\123.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 808, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 228, 181));
		panel.setBounds(35, 35, 720, 391);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btn1 = new JButton("Cakes");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu1 j = new menu1();
				j.setVisible(true);
			}
		});
		btn1.setForeground(new Color(255, 228, 181));
		btn1.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn1.setBackground(new Color(128, 0, 0));
		btn1.setBounds(63, 156, 138, 47);
		panel.add(btn1);
		
		JButton btn2 = new JButton("Pastries");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu2 j = new menu2();
				j.setVisible(true);
			}
		});
		btn2.setForeground(new Color(255, 228, 181));
		btn2.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn2.setBackground(new Color(128, 0, 0));
		btn2.setBounds(282, 156, 138, 47);
		panel.add(btn2);
		
		JButton btn3 = new JButton("Cupcakes");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu3 j = new menu3();
				j.setVisible(true);
			}
		});
		btn3.setForeground(new Color(255, 228, 181));
		btn3.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn3.setBackground(new Color(128, 0, 0));
		btn3.setBounds(499, 156, 159, 47);
		panel.add(btn3);
	}

}
