import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class login extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DELL\\Desktop\\New folder\\123.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 678, 678);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 228, 181));
		panel.setBounds(35, 35, 595, 573);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label1 = new JLabel("");
		label1.setIcon(new ImageIcon("C:\\Users\\DELL\\Desktop\\New folder\\123.jpg"));
		label1.setBounds(21, 26, 547, 442);
		panel.add(label1);
		
		JButton btn1 = new JButton("Sign Up");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				signup j = new signup();
				j.setVisible(true);
			}
		});
		btn1.setBackground(new Color(128, 0, 0));
		btn1.setForeground(new Color(255, 228, 181));
		btn1.setFont(new Font("Arial", Font.BOLD, 20));
		btn1.setBounds(113, 491, 123, 50);
		panel.add(btn1);
		
		JButton btn2 = new JButton("Login");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginpg j = new loginpg();
				j.setVisible(true);
			}
		});
		btn2.setBackground(new Color(128, 0, 0));
		btn2.setForeground(new Color(255, 228, 181));
		btn2.setFont(new Font("Arial", Font.BOLD, 20));
		btn2.setBounds(364, 491, 112, 50);
		panel.add(btn2);
	}
}
