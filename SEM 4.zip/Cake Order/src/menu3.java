import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class menu3 extends JFrame {

	private JPanel contentPane;
	private JTextField txt1;
	private JTextField txt2;
	private JTable t1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu3 frame = new menu3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menu3() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\DELL\\Desktop\\New folder\\123.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1201, 813);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 228, 181));
		panel.setBounds(35, 35, 1115, 679);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label1 = new JLabel("Cupcake Types");
		label1.setForeground(new Color(128, 0, 0));
		label1.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label1.setBounds(99, 52, 178, 38);
		panel.add(label1);
		
		JComboBox cb1 = new JComboBox();
		cb1.setBounds(385, 52, 207, 38);
		panel.add(cb1);
		cb1.setModel(new DefaultComboBoxModel(new String[] {"","Vanilla","Strawberry","Cupid's","Red Velvet","Maple Pumpkin","Moist Chocolate","Mint Chocolate Chip","Lemon Blueberry","Triple Chocolate","Others"}));
		
		JLabel label2 = new JLabel("Price");
		label2.setForeground(new Color(128, 0, 0));
		label2.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label2.setBounds(99, 139, 84, 43);
		panel.add(label2);
		
		JComboBox cb2 = new JComboBox();
		cb2.setBounds(385, 139, 207, 43);
		panel.add(cb2);
		cb2.setModel(new DefaultComboBoxModel(new String[] {"","100/-","120/-","150/-","180/-","200/-","220/-","250/-","280/-","300/-"}));
		
		JLabel label3 = new JLabel("Required Date");
		label3.setForeground(new Color(128, 0, 0));
		label3.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label3.setBounds(99, 230, 178, 38);
		panel.add(label3);
		
		txt1 = new JTextField();
		txt1.setColumns(10);
		txt1.setBounds(385, 230, 207, 38);
		panel.add(txt1);
		
		JButton btn1 = new JButton("Back");
		btn1.setForeground(new Color(255, 228, 181));
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu j = new menu();
				j.setVisible(true);
			}
		});
		btn1.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn1.setBackground(new Color(128, 0, 0));
		btn1.setBounds(99, 417, 98, 47);
		panel.add(btn1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(128, 0, 0));
		panel_1.setBounds(813, 364, 217, 279);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label4 = new JLabel("");
		label4.setIcon(new ImageIcon("C:\\Users\\DELL\\Desktop\\New folder\\cupcake.png"));
		label4.setBounds(10, 11, 197, 257);
		panel_1.add(label4);
		
		JLabel label5 = new JLabel("Mobile Number");
		label5.setForeground(new Color(128, 0, 0));
		label5.setFont(new Font("Lucida Calligraphy", Font.BOLD, 20));
		label5.setBounds(99, 326, 188, 38);
		panel.add(label5);
		
		txt2 = new JTextField();
		txt2.setColumns(10);
		txt2.setBounds(385, 326, 207, 38);
		panel.add(txt2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(128, 0, 0));
		panel_2.setBounds(633, 24, 452, 296);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		t1 = new JTable();
		t1.setFont(new Font("Century Schoolbook", Font.BOLD, 12));
		t1.setBackground(new Color(255, 250, 205));
		t1.setForeground(new Color(0, 0, 0));
		t1.setModel(new DefaultTableModel(
			new Object[][] {
				{"Cupcake Types", "Price", "Required Date", "Mobile Number"},
			},
			new String[] {
					"Cupcake Types", "Price", "Required Date", "Mobile Number"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		t1.getColumnModel().getColumn(0).setResizable(false);
		t1.setSurrendersFocusOnKeystroke(true);
		t1.setFillsViewportHeight(true);
		t1.setColumnSelectionAllowed(true);
		t1.setCellSelectionEnabled(true);
		t1.setBounds(10, 11, 423, 271);
		panel_2.add(t1);
		
		JButton btn2 = new JButton("Submit");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(txt1.getText().isEmpty() || txt2.getText().isEmpty()) {
					JOptionPane.showMessageDialog(btn2, "Enter Your Details");
					
				}
				else {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onesign","root","Lavanya@02");
					String query="insert into cupcakeslist values(?,?,?,?)";
					PreparedStatement ps=con.prepareStatement(query);
					ps.setString(1, cb1.getSelectedItem().toString());
					ps.setString(2, cb2.getSelectedItem().toString());
					ps.setString(3, txt1.getText());
					ps.setString(4, txt2.getText());
					int i = ps.executeUpdate();
				
				} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(btn2, "Order Submitted Successfully...");
			}
			}
		});
		btn2.setForeground(new Color(255, 228, 181));
		btn2.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn2.setBackground(new Color(128, 0, 0));
		btn2.setBounds(385, 417, 124, 47);
		panel.add(btn2);
		
		JButton btn3 = new JButton("Bill");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onesign","root","Lavanya@02");
					Statement st=con.createStatement();
					String query="select * from cupcakeslist";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd= (ResultSetMetaData) rs.getMetaData();
					DefaultTableModel model=(DefaultTableModel) t1.getModel();
					
					int cols=rsmd.getColumnCount();
					String[] colName=new String[cols];
					for(int i=0;i<cols;i++)
						colName[i]=rsmd.getColumnName(i+1);
					model.setColumnIdentifiers(colName);
					String cupcaketypes,price,requireddate,mobilenumber;
					while(rs.next()) {
						cupcaketypes=rs.getString(1);
						price=rs.getString(2);
						requireddate=rs.getString(3);
						mobilenumber=rs.getString(4);
						String[] row= {cupcaketypes,price,requireddate,mobilenumber};
						model.addRow(row);
					}
					st.close();
					con.close();     
				}
				
				catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
			} 

			}
		});
		btn3.setForeground(new Color(255, 228, 181));
		btn3.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn3.setBackground(new Color(128, 0, 0));
		btn3.setBounds(249, 583, 84, 47);
		panel.add(btn3);
		
		JButton btn4 = new JButton("Finish");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(btn3, "Thank You For Your Order...");
			}
		});
		btn4.setForeground(new Color(255, 228, 181));
		btn4.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn4.setBackground(new Color(128, 0, 0));
		btn4.setBounds(534, 583, 124, 47);
		panel.add(btn4);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBackground(new Color(128, 0, 0));
		panel_3.setBounds(0, 503, 1115, 37);
		panel.add(panel_3);
		
		JButton btn5 = new JButton("Add");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu j = new menu();
				j.setVisible(true);
			}
		});
		btn5.setForeground(new Color(255, 228, 181));
		btn5.setFont(new Font("Lucida Calligraphy", Font.BOLD, 22));
		btn5.setBackground(new Color(128, 0, 0));
		btn5.setBounds(688, 417, 93, 47);
		panel.add(btn5);
		
		
	}

}
